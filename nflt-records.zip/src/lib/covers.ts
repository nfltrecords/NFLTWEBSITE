import gr4life from "@/assets/covers/verified/821440674572.jpg.asset.json";
import lecran from "@/assets/covers/verified/199951252436.jpg.asset.json";
import socialCommunity from "@/assets/covers/verified/199954147302.jpg.asset.json";
import dilemma from "@/assets/covers/verified/199955701558.jpg.asset.json";
import neverfake from "@/assets/covers/verified/199955715135.jpg.asset.json";
import hustleGrind from "@/assets/covers/verified/199955715203.jpg.asset.json";
import theLuxury from "@/assets/covers/verified/199955740199.jpg.asset.json";
import genocides from "@/assets/covers/verified/199955742094.jpg.asset.json";
import nousYSommes from "@/assets/covers/verified/199956222809.jpg.asset.json";
import zeroPlus from "@/assets/covers/verified/199956554184.jpg.asset.json";
import maLuxure2 from "@/assets/covers/verified/199956557857.jpg.asset.json";
import n836722 from "@/assets/covers/verified/199751168234.jpg.asset.json";
import transcendence from "@/assets/covers/verified/199751170992.jpg.asset.json";
import hot from "@/assets/covers/verified/199751508283.jpg.asset.json";
import dopestVol1 from "@/assets/covers/verified/199751511160.jpg.asset.json";
import inMyParty from "@/assets/covers/verified/199751512501.jpg.asset.json";
import dopestVol2 from "@/assets/covers/verified/199751514697.jpg.asset.json";
import maLuxure from "@/assets/covers/verified/199751613871.jpg.asset.json";
import goldLogo from "@/assets/covers/nflt-records-gold-logo.jpg.asset.json";

// 16 screenshot-verified uploads plus 2 owner-confirmed originals attached in the thread.
export const releaseCovers: Record<string, string> = {
  "199955740199": theLuxury.url,
  "199956554184": zeroPlus.url,
  "199956222809": nousYSommes.url,
  "199955715135": neverfake.url,
  "199955742094": genocides.url,
  "199955701558": dilemma.url,
  "199955715203": hustleGrind.url,
  "199751511160": dopestVol1.url,
  "199751512501": inMyParty.url,
  "199751514697": dopestVol2.url,
  "199751613871": maLuxure.url,
  "199751508283": hot.url,
  "199751168234": n836722.url,
  "199751170992": transcendence.url,
  "199956557857": maLuxure2.url,
  "199954147302": socialCommunity.url,
  "199951252436": lecran.url,
  "821440674572": gr4life.url,
};

// Official NFLT RECORDS gold logo supplied by the owner.
export const goldLogoUrl = goldLogo.url;
