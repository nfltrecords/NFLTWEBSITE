NFLT RECORDS — PRIVATE PRE-INTEGRATION PACKAGE

Contents
- covers-original/: all 18 owner-uploaded JPG files, byte-for-byte copies
- covers-by-upc/: convenient renamed copies, keyed by existing catalogue UPC
- catalogue-artwork-map.csv: 18 release-to-artwork associations; track counts deliberately left unverified
- audio-originals/: 36 uploaded audio files, unchanged
- audio-inventory.csv: technical metadata only (duration/codec/sample rate/channels)
- evidence-screenshots/: extracted DistroKid/Spotify screenshots used for associations

Important verification notes
1. The filenames begin with “3000x3000”, but the actual pixel dimensions measured from the uploaded JPG binaries are 1536x1536 for all 18. No upscaling or re-encoding was applied. Confirm whether these are intended source originals or export derivatives before calling them 3000x3000 HD.
2. No track count is asserted for any of the 18 UPCs. Audio files include a mix of individual tracks, long masters, medleys, and possible radio material; file count is not an album track count.
3. The audio files are preserved as uploaded. This package does not authorize public streaming, radio playout, sale, distribution, or downloads.
4. The existing production website was not modified, no Lovable AI task/credit was used, and nothing was deployed. This is a local integration package pending direct source-control/project file write access.
5. Shop remains catalogue/inquiry only; no checkout or payment workflow was added.
